/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo.pboframe;

import bfreader.ClassCetakPDF;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pbo.classcode.ClassProduk;
import pbo.classcode.ClassTransaksiPengiriman;


/**
 *
 * @author rahmania
 */
public class irfrmTrxPengiriman extends javax.swing.JInternalFrame {

    String namalogin;
    ResultSet rs;
    Connection conn;
    String tanggal, idtrx,Petugas, nama_kurir, nama_mitra, telpon,alamat_mitra, kodeBrg, namaProduk, desBrg,
            status1,status2,jam;
    Date date;
    DefaultTableModel tablemodel;

    /**
     * Creates new form irfrmTrxPenjualan
     */
    public irfrmTrxPengiriman() {
        initComponents();
        loadDataTrx();
//        tampiljamtanggal();
    }

    public irfrmTrxPengiriman(String nama) {
        initComponents();
        loadDataTrx();
//        tampiljamtanggal();
        ModelTabelTransaksi();
        namalogin = nama;
    }
    
    public void koneksi() throws SQLException {
        conn = null;
        String url = "jdbc:mysql://127.0.0.1/pbouas";
        String user = "root";
        String pass = "";
        conn = DriverManager.getConnection(url, user, pass);
    }

    public void loadDataTrx() {
        ClassTransaksiPengiriman ctp = new ClassTransaksiPengiriman();
        ctp.getDataTrxPengiriman();
        int ndata = ctp.getNumberTrxPengiriman();
        lblTrx.setText("INV-" + (ndata + 1));
    }

//    private void tampiljamtanggal() {
//        jam = null;
//        tanggal = null;
//        Thread thread = new Thread() {
//            @Override
//            public void run() {
//                for (;;) {
//                    try {
//                        Calendar cal = new GregorianCalendar();
//                        tanggal = (cal.get(Calendar.YEAR)
//                                + "-" + (cal.get(Calendar.MONTH) + 1)
//                                + "-" + cal.get(Calendar.DATE));
//                        jam = (cal.get(Calendar.HOUR)
//                                + " : " + cal.get(Calendar.MINUTE)
//                                + " : " + cal.get(Calendar.SECOND));
//                        lblJamTgl.setText(jam + " " + tanggal);
//                        sleep(1000);
//                    } catch (InterruptedException ex) {
//                        Logger.getLogger(irfrmTrxPengiriman.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                }
//            }
//        ;
//        };
//        thread.start();
//    }

//    public void loadDataBarang(String key) {
//        ClassProduk cb = new ClassProduk();
//        cb.getDataProdukKode(key);
//        Object[][] data = cb.getAllDataProduk();
//        txtMitra.setText(data[0][1] + "");
//        txtPetugas.setText(data[0][2] + "");
//    }

    public void loadData() {

        ModelTabelTransaksi();
        ClassTransaksiPengiriman cu = new ClassTransaksiPengiriman();
        cu.getDataTrxPengiriman();
        int ndata = cu.getNumberDataTrxPengiriman();
        lblTrx.setText("ID-"+(ndata+1));
        Object[][] data = cu.getAllDataTrxPengiriman();
        Object[] data1 = new Object[9];
        for (int i = 0; i < ndata; i++) {
            for (int j = 0; j < 9; j++) {
                data1[j] = data[i][j];
            }
            tablemodel.addRow(data1);
        }

    }

    public void ModelTabelTransaksi() {
        tablemodel = new DefaultTableModel();
        jTable1.setModel(tablemodel);
        tablemodel.addColumn("idtrx");
        tablemodel.addColumn("Petugas");
        tablemodel.addColumn("Nama Kurir");
        tablemodel.addColumn("Nama Mitra");
        tablemodel.addColumn("Alamat Mitra");
        tablemodel.addColumn("Telpon Mitra");
        tablemodel.addColumn("Kode");
        tablemodel.addColumn("Nama Produk");
        tablemodel.addColumn("Deskripsi Produk");
        tablemodel.addColumn("Tanggal");
        tablemodel.getDataVector().removeAllElements();
        tablemodel.fireTableDataChanged(); //To change body of generated methods, choose Tools | Templates.
    }

    public void clearData() {
        txtKurir.setText("");
        txtMitra.setText("");
        txtKode.setText("");
        txtPetugas.setText("");
        txtTelp.setText("");
        txtAlamat.setText("");
        txtProduk.setText("");
        txtDes.setText("");
        //To change body of generated methods, choose Tools | Templates.
    }

    public void clearAllData() {
        txtKurir.setText("");
        txtMitra.setText("");
        txtKode.setText("");
        txtPetugas.setText("");
        txtTelp.setText("");
        txtAlamat.setText("");
        txtProduk.setText("");
        txtDes.setText("");
        loadDataTrx();
        ModelTabelTransaksi();
        //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblTrx = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblJamTgl = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtKurir = new javax.swing.JTextField();
        txtTelp = new javax.swing.JTextField();
        txtMitra = new javax.swing.JTextField();
        txtKode = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtPetugas = new javax.swing.JTextField();
        txtAlamat = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtProduk = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtDes = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jTextField1 = new javax.swing.JTextField();
        btn_cetak = new javax.swing.JButton();
        txt_kode1 = new javax.swing.JTextField();

        jLabel5.setText("Kode");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Transaksi Penjualan");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(271, 11, -1, -1));

        lblTrx.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblTrx.setForeground(new java.awt.Color(0, 0, 102));
        lblTrx.setText("Trx01");
        getContentPane().add(lblTrx, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 58, -1, -1));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblJamTgl.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblJamTgl.setForeground(new java.awt.Color(0, 0, 102));
        lblJamTgl.setText("Tanggal Jam");
        jPanel1.add(lblJamTgl, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 70, -1, -1));

        jButton2.setText("+");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 190, -1, 40));

        jButton1.setText("H");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 140, -1, 40));

        jLabel12.setText("@rahmania");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 640, -1, -1));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode", "Nama", "Item", "Harga", "Sub Total"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 1070, 240));

        txtKurir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKurirActionPerformed(evt);
            }
        });
        txtKurir.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtKurirKeyTyped(evt);
            }
        });
        jPanel1.add(txtKurir, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 172, 150, 40));

        txtTelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelpActionPerformed(evt);
            }
        });
        txtTelp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelpKeyTyped(evt);
            }
        });
        jPanel1.add(txtTelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 120, 150, 40));

        txtMitra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMitraActionPerformed(evt);
            }
        });
        jPanel1.add(txtMitra, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 150, 40));

        txtKode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKodeActionPerformed(evt);
            }
        });
        jPanel1.add(txtKode, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 220, 150, 40));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Nama Mitra");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("Kode");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 230, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setText("Nama Kurir");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        txtPetugas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPetugasActionPerformed(evt);
            }
        });
        jPanel1.add(txtPetugas, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 150, 40));
        jPanel1.add(txtAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 170, 150, 40));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("Petugas");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText("Telp Mitra");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 130, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("Alamat Tujuan");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 180, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText("Nama Produk");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 130, -1, -1));
        jPanel1.add(txtProduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 120, 150, 40));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setText("Tanggal");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 240, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setText("Deskripsi Produk");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 190, -1, -1));

        txtDes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDesActionPerformed(evt);
            }
        });
        jPanel1.add(txtDes, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 180, 150, 40));

        jButton3.setText("CETAK");
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 560, 100, 30));
        jPanel1.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 240, 150, 40));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(829, 560, 140, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 660));

        btn_cetak.setText("Cetak");
        btn_cetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cetakActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cetak, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 590, 100, 40));

        txt_kode1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_kode1ActionPerformed(evt);
            }
        });
        txt_kode1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_kode1KeyTyped(evt);
            }
        });
        getContentPane().add(txt_kode1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 100, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtKurirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKurirActionPerformed
         try {
            koneksi();
            String key = txtKurir.getText();
            String sql = "select * from kurir where na  ma='" + key + "'";
            Statement stat = conn.createStatement();
            ResultSet rst = stat.executeQuery(sql);
            

        } catch (SQLException ex) {
            Logger.getLogger(irfrmTrxPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }// TODO add your handling code here:
    }//GEN-LAST:event_txtKurirActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
//        String petugas = txtPetugas.getText();
//        String kurir = txtKurir.getText();
//        String namaMitra = txtMitra.getText();
//        String alamatMitra = txtAlamat.getText();
//        String telp = txtTelp.getText();
//        String kode = txtKode.getText();
//        String Produk = txtKode.getText();
//        String desBrg = txtAlamat.getText();
//        
//        int kodew = Integer.valueOf(txtKode.getText());
//        String produk = txtProduk.getText();
//        clearData();
//
//        Object[] data = {petugas,kurir, namaMitra, telp, kode, produk,desBrg};
//        tablemodel.addRow(data);
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        
//        String merk = comboKamera.getSelectedItem().toString();
        String idtrx = lblTrx.getText();
        String Petugas = txtPetugas.getText();
        String nama_kurir = txtKurir.getText();
        String nama_mitra = txtMitra.getText();
        String alamat_mitra = txtAlamat.getText();
        String telpon = txtTelp.getText();
        String kodeBrg = txtKode.getText();
        String namaProduk= txtKode.getText();
        String desBrg = txtAlamat.getText();
        String tanggal = (dateFormat.format(jDateChooser1.getDate()));
    
        
        ClassTransaksiPengiriman ct = new ClassTransaksiPengiriman();
        ct.InsertTransaksi(idtrx,Petugas, nama_kurir, nama_mitra, telpon,
        alamat_mitra,  kodeBrg, namaProduk, desBrg,tanggal );
        
//        pengembalian p = new pengembalian(nama);
//        p.setVisible(true);;
//        this.getDesktopPane().add(p);
//        dispose();
        Object[] data = {idtrx,Petugas, nama_kurir, nama_mitra, telpon,
        alamat_mitra,  kodeBrg, namaProduk, desBrg,tanggal};
        clearData();
        tablemodel.addRow(data);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed
    int idx_table, subtotal;
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int i = jTable1.getSelectedRow();
        if (i == -1) {
            return;
        }
        idtrx = (String) tablemodel.getValueAt(i, 0);
        Petugas = (String) tablemodel.getValueAt(i, 1);
        nama_kurir = (String) tablemodel.getValueAt(i, 2);
        nama_mitra = (String) tablemodel.getValueAt(i, 3);
        telpon = (String) tablemodel.getValueAt(i, 4);
        alamat_mitra = (String) tablemodel.getValueAt(i, 5);
        kodeBrg = (String) tablemodel.getValueAt(i, 6);
        namaProduk = (String) tablemodel.getValueAt(i, 7);
        desBrg = (String) tablemodel.getValueAt(i, 8);
        tanggal = (String) tablemodel.getValueAt(i, 9);
        
//        itemBrg = (String) tablemodel.getValueAt(i, 9);

// TODO add your handling code here:
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        tablemodel.removeRow(idx_table);
//        int total = Integer.valueOf(lbl_total.getText());
//        total = total - subtotal;
//        lbl_total.setText(total + "");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_cetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cetakActionPerformed
        String[][] data = new String[jTable1.getRowCount()][jTable1.getColumnCount()];
        for (int i = 0; i < jTable1.getRowCount(); i++) {
            for (int j = 0; j < jTable1.getColumnCount(); j++) {
                data[i][j] = String.valueOf(tablemodel.getValueAt(i, j));

            }
        }

        ClassCetakPDF cc = new ClassCetakPDF();
        String[] jdlTb1 = {"kode", "nama", "item", "harga item", "sub total"};
        cc.CetakTabel("Daftar trx penjualan", jdlTb1, data, jTable1.getRowCount(), jTable1.getColumnCount());// TODO add your handling code here:
    }//GEN-LAST:event_btn_cetakActionPerformed

    private void txtMitraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMitraActionPerformed
        // TODO add your handling code here:
        try {
            koneksi();
            String key = txtMitra.getText();
            String sql = "select * from mitra where nama_mitra ='" + key + "'";
            Statement stat = conn.createStatement();
            ResultSet rst = stat.executeQuery(sql);
            try {
                while (rst.next()) {
                    this.txtTelp.setText(rst.getString("telpon"));
                    this.txtAlamat.setText(rst.getString("alamat_mitra"));
                    
                }
            } catch (SQLException ex) {
            }

        } catch (SQLException ex) {
            Logger.getLogger(irfrmTrxPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtMitraActionPerformed

    private void txtPetugasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPetugasActionPerformed
        // TODO add your handling code here:
        try {
            koneksi();
            String key = txtPetugas.getText();
            String sql = "select * from user where nama='" + key + "'";
            Statement stat = conn.createStatement();
            ResultSet rst = stat.executeQuery(sql);
            

        } catch (SQLException ex) {
            Logger.getLogger(irfrmTrxPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtPetugasActionPerformed

    private void txtKurirKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtKurirKeyTyped
        // TODO add your handling code here:
//        loadDataBarang(txtKurir.getText());
    }//GEN-LAST:event_txtKurirKeyTyped

    private void txt_kode1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_kode1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_kode1ActionPerformed

    private void txt_kode1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_kode1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_kode1KeyTyped

    private void txtTelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelpActionPerformed

    private void txtTelpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelpKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelpKeyTyped

    private void txtKodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKodeActionPerformed
        // TODO add your handling code here:
        try {
            koneksi();
            String key = txtKode.getText();
            String sql = "select * from produk where id_produk='" + key + "'";
            Statement stat = conn.createStatement();
            ResultSet rst = stat.executeQuery(sql);
            try {
                while (rst.next()) {
                    this.txtProduk.setText(rst.getString("nama_produk"));
                    this.txtDes.setText(rst.getString("desBrg"));
                }
            } catch (SQLException ex) {
            }

        } catch (SQLException ex) {
            Logger.getLogger(irfrmTrxPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtKodeActionPerformed

    private void txtDesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cetak;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblJamTgl;
    private javax.swing.JLabel lblTrx;
    private javax.swing.JTextField txtAlamat;
    private javax.swing.JTextField txtDes;
    private javax.swing.JTextField txtKode;
    private javax.swing.JTextField txtKurir;
    private javax.swing.JTextField txtMitra;
    private javax.swing.JTextField txtPetugas;
    private javax.swing.JTextField txtProduk;
    private javax.swing.JTextField txtTelp;
    private javax.swing.JTextField txt_kode1;
    // End of variables declaration//GEN-END:variables

    

}
