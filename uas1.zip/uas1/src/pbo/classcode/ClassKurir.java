/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo.classcode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author
 */
public class ClassKurir {

    private String id_kurir;
    private String nama_kurir;
    private int telpon;
    private int ndata = 0;
    private Object[][] data;

    private Connection conn;
    private Statement st;

    public int getNumberDataKurir() {
        return ndata;
    }

    public Object[][] getAllDataKurir() {
        return data;
    }

    public ClassKurir() {
    }

    public void TampilKurir() {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "SELECT * from kurir";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Object[] o = new Object[3];
                o[0] = rs.getString("id_kurir");
                o[1] = rs.getString("nama_kurir");
                o[2] = rs.getString("telpon");

                System.out.println(o[0] + "\t" + o[1] + "\t" + o[2]  );
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassKurir.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void InsertKurir(String id_kurir, String nama_kurir, int telpon) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "INSERT INTO kurir VALUES (?, ?, ?)";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_kurir);
                p.setString(2, nama_kurir);
                p.setInt(3, telpon);
                p.execute();
                System.out.println("Sukses menambah data...");
                JOptionPane.showMessageDialog(null, "Sukses menambah data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassKurir.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void UpdateKurir(String id_kurir, String nama_kurir, int telpon) {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();    //hubungkan kelas
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "UPDATE kurir SET nama_kurir=?, telpon=? WHERE id_kurir=?";    //query
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_kurir);
                p.setString(2, nama_kurir);
                p.setInt(3, telpon);
                p.executeUpdate();
                p.close();
                System.out.println("Sukses update data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DeleteKurir(String id_kurir) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "DELETE FROM kurir WHERE id_kurir=?";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_kurir);
                p.executeUpdate();
                System.out.println("Sukses menghapus data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassKurir.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getDataKurir() {

        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from kurir";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from kurir";
            rs = st.executeQuery(sql);
            data = new Object[ndata][3];
            int idx = 0;
            while (rs.next()) {         //tangkap hasil query
                data[idx][0] = rs.getString("id_kurir");
                data[idx][1] = rs.getString("nama_kurir");
                data[idx][2] = rs.getString("telpon");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassKurir.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void getDataKurir(String key){
        
        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from kurir where id_mitra like '%"+key+"%'" ;
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from kurir where nama_kurir like '%"+key+"%'" ;
            rs = st.executeQuery(sql);
            data = new Object[ndata][3];
            int idx=0;
            while (rs.next()) {
                data[idx][0] = rs.getString("id_kurir");
                data[idx][1] = rs.getString("nama_kurir");
                data[idx][2] = rs.getString("telpon");
                idx++;
            }
            rs.close();  
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassKurir.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    public void getDataProdukKode(String key){
        
        try {
            conn=ClassConnection.getKoneksi();
            st=conn.createStatement();
            String sql="Select count(*) from kurir where id_kurir like '%"+key+"%'";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                ndata=rs.getInt("COUNT(*)");
            }
            sql="Select * from kurir where id_kurir like '%"+key+"%'";
            rs=st.executeQuery(sql);
            data=new Object[ndata][3];
            int idx=0;
            while(rs.next()){
                data[idx][0] = rs.getString("id_kurir");
                data[idx][1] = rs.getString("nama_kurir");
                data[idx][2] = rs.getString("telpon");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassKurir.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
//    public void UpdateStok(String[][] data, int n) {
//        try {
//            conn = ClassConnection.getKoneksi();
//            st = conn.createStatement();
//            for (int i = 0; i < n; i++) {
//                kode = data[i][0];
//                System.out.println(kode);
//                int itemBrg = Integer.valueOf(data[1][2]);
//                stok = getStok(kode) - itemBrg;
//                String sql = "UPDATE barang SET stok=? WHERE kode=?";
//                try (PreparedStatement p = conn.prepareStatement(sql)) {
//                    p.setInt(1, stok);
//                    p.setString(2, kode);
//                    p.executeUpdate();
//                    p.close();
//                }
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//    
//    public int getStok(String kode){
//        try {
//            conn = (Connection) ClassConnection.getKoneksi();
//            st = (Statement) conn.createStatement();
//            String sql = "Select stok from barang where kode='" + kode + "';" ;
//            ResultSet rs = st.executeQuery(sql);
//            while (rs.next()) {
//                ndata = rs.getInt("stok");
//            }
//            rs.close();  
//            st.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return stok;
//    }

    

   

}
