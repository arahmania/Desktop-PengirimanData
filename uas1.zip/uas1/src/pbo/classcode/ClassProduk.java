/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo.classcode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author
 */
public class ClassProduk {

    private String id_produk;
    private String nama_produk;
    private String desBrg;
    private int ndata = 0;
    private Object[][] data;

    private Connection conn;
    private Statement st;

    public int getNumberDataProduk() {
        return ndata;
    }

    public Object[][] getAllDataProduk() {
        return data;
    }

    public ClassProduk() {
    }

    public void TampilProduk() {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "SELECT * from produk";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Object[] o = new Object[2];
                o[0] = rs.getString("id_produk");
                o[1] = rs.getString("nama_produk");
                o[2] = rs.getString("desBrg");
                System.out.println(o[0] + "\t" + o[1] + "\t" + o[2] );
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void InsertProduk(String id_produk, String nama_produk, String desBrg) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "INSERT INTO produk VALUES (?, ?,?)";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_produk);
                p.setString(2, nama_produk);
                p.setString(3, desBrg);
                p.execute();
                System.out.println("Sukses menambah data...");
                JOptionPane.showMessageDialog(null, "Sukses menambah data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void UpdateProduk(String id_produk, String nama_produk,  String desBrg) {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();    //hubungkan kelas
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "UPDATE produk SET nama_produk=?, desBrg=? WHERE id_produk=?";    //query
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, nama_produk);
                p.setString(2, desBrg);
                p.setString(3, id_produk);
                p.executeUpdate();
                p.close();
                System.out.println("Sukses update data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DeleteProduk(String id_produk) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "DELETE FROM produk WHERE id_produk=?";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_produk);
                p.executeUpdate();
                System.out.println("Sukses menghapus data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getDataProduk() {

        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from produk";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from produk";
            rs = st.executeQuery(sql);
            data = new Object[ndata][3];
            int idx = 0;
            while (rs.next()) {         //tangkap hasil query
                data[idx][0] = rs.getString("id_produk");
                data[idx][1] = rs.getString("nama_produk");
                data[idx][2] = rs.getString("desBrg");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void getDataProduk(String key){
        
        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from produk where id_produk like '%"+key+"%'" ;
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from produk where nama_produk like '%"+key+"%'" ;
            rs = st.executeQuery(sql);
            data = new Object[ndata][3];
            int idx=0;
            while (rs.next()) {
                data [idx][0] = rs.getString("id_produk");
                data [idx][1] = rs.getString("nama_produk");
                data[idx][2] = rs.getString("desBrg");
                idx++;
            }
            rs.close();  
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    public void getDataProdukKode(String key){
        
        try {
            conn=ClassConnection.getKoneksi();
            st=conn.createStatement();
            String sql="Select count(*) from produk where id_produk like '%"+key+"%'";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                ndata=rs.getInt("COUNT(*)");
            }
            sql="Select * from produk where id_produk like '%"+key+"%'";
            rs=st.executeQuery(sql);
            data=new Object[ndata][3];
            int idx=0;
            while(rs.next()){
                data[idx][0]=rs.getString("id_produk");
                data[idx][1]=rs.getString("nama_produk");
                data[idx][2] = rs.getString("desBrg");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
//    public void UpdateStok(String[][] data, int n) {
//        try {
//            conn = ClassConnection.getKoneksi();
//            st = conn.createStatement();
//            for (int i = 0; i < n; i++) {
//                kode = data[i][0];
//                System.out.println(kode);
//                int itemBrg = Integer.valueOf(data[1][2]);
//                stok = getStok(kode) - itemBrg;
//                String sql = "UPDATE barang SET stok=? WHERE kode=?";
//                try (PreparedStatement p = conn.prepareStatement(sql)) {
//                    p.setInt(1, stok);
//                    p.setString(2, kode);
//                    p.executeUpdate();
//                    p.close();
//                }
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//    
//    public int getStok(String kode){
//        try {
//            conn = (Connection) ClassConnection.getKoneksi();
//            st = (Statement) conn.createStatement();
//            String sql = "Select stok from barang where kode='" + kode + "';" ;
//            ResultSet rs = st.executeQuery(sql);
//            while (rs.next()) {
//                ndata = rs.getInt("stok");
//            }
//            rs.close();  
//            st.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassProduk.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return stok;
//    }

}
