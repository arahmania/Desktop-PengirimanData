/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo.classcode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author
 */
public class ClassMitra {

    private String id_mitra;
    private String nama_mitra;
    private String alamat_mitra;
    private int telpon;
    private int ndata = 0;
    private Object[][] data;

    private Connection conn;
    private Statement st;

    public int getNumberDataMitra() {
        return ndata;
    }

    public Object[][] getAllDataMitra() {
        return data;
    }

    public ClassMitra() {
    }

    public void TampilMitra() {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "SELECT * from mitra";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Object[] o = new Object[4];
                o[0] = rs.getString("id_mitra");
                o[1] = rs.getString("nama_mitra");
                o[2] = rs.getString("alamat_mitra");
                o[3] = rs.getString("telpon");

                System.out.println(o[0] + "\t" + o[1] + "\t" + o[2] + "\t" + o[3] );
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void InsertMitra(String id_mitra, String nama_mitra, String alamat_mitra, int telpon) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "INSERT INTO mitra VALUES (?, ?, ?, ?)";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_mitra);
                p.setString(2, nama_mitra);
                p.setString(3, alamat_mitra);
                p.setInt(4, telpon);
                p.execute();
                System.out.println("Sukses menambah data...");
                JOptionPane.showMessageDialog(null, "Sukses menambah data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void UpdateMitra(String id_mitra, String nama_mitra, String alamat_mitra, int telpon) {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();    //hubungkan kelas
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "UPDATE mitra SET nama_mitra=?, alamat_mitra=?, telpon=? WHERE id_mitra=?";    //query
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, nama_mitra);
                p.setString(2, alamat_mitra);
                p.setInt(3, telpon);
                p.setString(4, id_mitra);
                p.executeUpdate();
                p.close();
                System.out.println("Sukses update data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DeleteMitra(String id_mitra) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "DELETE FROM mitra WHERE id_mitra=?";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, id_mitra);
                p.executeUpdate();
                System.out.println("Sukses menghapus data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getDataMitra() {

        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from mitra";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from mitra";
            rs = st.executeQuery(sql);
            data = new Object[ndata][4];
            int idx = 0;
            while (rs.next()) {         //tangkap hasil query
                data[idx][0] = rs.getString("id_mitra");
                data[idx][1] = rs.getString("nama_mitra");
                data[idx][2] = rs.getString("alamat_mitra");
                data[idx][3] = rs.getString("telpon");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void getDataMitra(String key){
        
        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from mitra where id_mitra like '%"+key+"%'" ;
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from mitra where nama_mitra like '%"+key+"%'" ;
            rs = st.executeQuery(sql);
            data = new Object[ndata][4];
            int idx=0;
            while (rs.next()) {
                data [idx][0] = rs.getString("id_mitra");
                data [idx][1] = rs.getString("nama_mitra");
                data [idx][2] = rs.getString("alamat_mitra");
                data [idx][3] = rs.getString("telpon");
                idx++;
            }
            rs.close();  
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    public void getDataBarangKode(String key){
        
        try {
            conn=ClassConnection.getKoneksi();
            st=conn.createStatement();
            String sql="Select count(*) from mitra where id_mitra like '%"+key+"%'";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                ndata=rs.getInt("COUNT(*)");
            }
            sql="Select * from mitra where id_mitra like '%"+key+"%'";
            rs=st.executeQuery(sql);
            data=new Object[ndata][4];
            int idx=0;
            while(rs.next()){
                data [idx][0] = rs.getString("id_mitra");
                data [idx][1] = rs.getString("nama_mitra");
                data [idx][2] = rs.getString("alamat_mitra");
                data [idx][3] = rs.getString("telpon");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
//    public void UpdateStok(String[][] data, int n) {
//        try {
//            conn = ClassConnection.getKoneksi();
//            st = conn.createStatement();
//            for (int i = 0; i < n; i++) {
//                kode = data[i][0];
//                System.out.println(kode);
//                int itemBrg = Integer.valueOf(data[1][2]);
//                stok = getStok(kode) - itemBrg;
//                String sql = "UPDATE barang SET stok=? WHERE kode=?";
//                try (PreparedStatement p = conn.prepareStatement(sql)) {
//                    p.setInt(1, stok);
//                    p.setString(2, kode);
//                    p.executeUpdate();
//                    p.close();
//                }
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//    
//    public int getStok(String kode){
//        try {
//            conn = (Connection) ClassConnection.getKoneksi();
//            st = (Statement) conn.createStatement();
//            String sql = "Select stok from barang where kode='" + kode + "';" ;
//            ResultSet rs = st.executeQuery(sql);
//            while (rs.next()) {
//                ndata = rs.getInt("stok");
//            }
//            rs.close();  
//            st.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassMitra.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return stok;
//    }

   

    

   

}
