/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo.classcode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Rahmania
 */
public class ClassTransaksiPengiriman {

    String idtrx;
    String petugas;
    String nama_kurir;
    String nama_mitra;
    String telpon;
    String alamat_mitra;
    String kodeBrg;
    String namaProduk;
    String desBrg;
    String tanggal;
//    String itemBrg;

    private int ndata = 0;
    private Object[][] data;

    private Connection conn;
    private Statement st;

    public ClassTransaksiPengiriman() {
    }

    public int getNumberDataTrxPengiriman() {
        return ndata;
    }

    public Object[][] getAllDataTrxPengiriman() {
        return data;
    }

    public void getDataTrxPengiriman() { 
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "Select count(*) from trx_suratjalan";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from trx_suratjalan";
            rs = st.executeQuery(sql);
            data = new Object[ndata][10];
            int idx = 0;
            while (rs.next()) {
                data[idx][0] = rs.getString("idtrx");
                data[idx][1] = rs.getString("petugas");
                data[idx][2] = rs.getString("nama_kurir");
                data[idx][3] = rs.getString("nama_mitra");
                data[idx][4] = rs.getString("telpon");
                data[idx][5] = rs.getString("alamat_mitra");
                data[idx][6] = rs.getString("kodeBrg");
                data[idx][7] = rs.getString("namaProduk");
                data[idx][8] = rs.getString("desBrg");
                data[idx][9] = rs.getString("tanggal");

                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//    public void getDataCari(String key) {
//
//        try {
//            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();
//            st = (com.mysql.jdbc.Statement) conn.createStatement();
//            String sql = "SELECT COUNT(DISTINCT idtrx) FROM trx_suratjalan WHERE idtrx LIKE '%" + key + "%'";
//            ResultSet rs = st.executeQuery(sql);
//            while (rs.next()) {
//                ndata = rs.getInt("COUNT(DISTINCT idtrx)");
//            }
//            sql = "SELECT tanggal, idtrx, Count(idtrx) AS njenis, "
//                    + "Sum(itemBrg) AS nitem, Sum(desBrg) AS pemasukan "
//                    + "FROM trx_suratjalan WHERE idtrx LIKE '%" + key + "%' GROUP BY idtrx";
//            System.out.println(sql);
//            rs = st.executeQuery(sql);
//            data = new Object[ndata][5];
//            int idx = 0;
//            while (rs.next()) {
//                data[idx][0] = rs.getString("tanggal");
//                data[idx][1] = rs.getString("idtrx");
//                data[idx][2] = rs.getString("njenis");
//                data[idx][3] = rs.getString("nitem");
//                data[idx][4] = rs.getString("pemasukan");
//                idx++;
//            }
//            rs.close();
//            st.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }

    public void getDataDetail(String kode) {
  try{
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "Select count(*) from trx_suratjalan where idtrx like '%"+kode+"%'";
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "select * from trx_suratjalan where nama_kurir like '%"+kode+"%'";
            rs = st.executeQuery(sql);
            data = new Object[ndata][10];
            int idx = 0;
            while (rs.next()) {
                data[idx][0] = rs.getString("idtrx");
//                data[idx][0] = rs.getString("id ");
                data[idx][1] = rs.getString("petugas");
                data[idx][2] = rs.getString("nama_kurir");
                data[idx][3] = rs.getString("nama_mitra");
                data[idx][4] = rs.getString("telpon");
                data[idx][5] = rs.getString("alamat_mitra");
                data[idx][6] = rs.getString("kodeProduk");
                data[idx][7] = rs.getString("namaProduk");
                data[idx][8] = rs.getString("desBrg");
                data[idx][9] = rs.getString("tanggal");
//                data[idx][9] = rs.getString("itembrg");

                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }

//    public void InsertTrxPengiriman(String tanggal, String petugas, String nama_kurir, String nama_mitra, String telpon,
//            String alamat_mitra, String kodeProduk, String namaProduk, String desBrg) {
//        try {
//            conn = (Connection) ClassConnection.getKoneksi();    //hubungkan kelas
//            st = (Statement) conn.createStatement();
//            String sql = "INSERT INTO trx_suratjalan VALUE (?,?,?,?,?,?,?,?,?)";    //query
//            try ( PreparedStatement p = conn.prepareStatement(sql)) {
//                p.setString(1, tanggal);
//                p.setString(2, petugas);
//                p.setString(3, nama_kurir);
//                p.setString(4, nama_mitra);      //belumselesaibenerin
//                p.setString(5, telpon);
//                p.setString(6, alamat_mitra);
//                p.setString(7, kodeProduk);
//                p.setString(8, namaProduk);
//                p.setString(9, desBrg);
//                p.execute();
//                System.out.println("Sukses menambahkan data...");
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    
    public void InsertTransaksi(String idtrx, String petugas, String nama_kurir, String nama_mitra, String telpon,
       String alamat_mitra, String kodeProduk, String namaProduk, String desBrg, String tanggal) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "INSERT INTO trx_suratjalan VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
            try ( PreparedStatement p = conn.prepareStatement(sql)) {
                 p.setString(1, idtrx);
                p.setString(2, petugas);
                p.setString(3, nama_kurir);
                p.setString(4, nama_mitra);      
                p.setString(5, telpon);
                p.setString(6, alamat_mitra);
                p.setString(7, kodeProduk);
                p.setString(8, namaProduk);
                p.setString(9, desBrg);
                p.setString(10, tanggal);
                p.execute();
                System.out.println("Sukses menambah data...");
                JOptionPane.showMessageDialog(null, "Transaksi Sukses...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    public int getNumberTrxPengiriman() {
        return ndata; //To change body of generated methods, choose Tools | Templates.
    }

    public void getDataTrxPengiriman(String key) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "Select count(*) from trx_suratjalan WHERE nama_kurir like '%"+key+"%'";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from trx_suratjalan WHERE nama_kurir like '%"+key+"%'";
            rs = st.executeQuery(sql);
            data = new Object[ndata][10];
            int idx = 0;
            while (rs.next()) {
                data[idx][0] = rs.getString("idtrx");
                data[idx][1] = rs.getString("petugas");
                data[idx][2] = rs.getString("nama_kurir");
                data[idx][3] = rs.getString("nama_mitra");
                data[idx][4] = rs.getString("telpon");
                data[idx][5] = rs.getString("alamat_mitra");
                data[idx][6] = rs.getString("kodeProduk");
                data[idx][7] = rs.getString("namaProduk");
                data[idx][8] = rs.getString("desBrg");
                data[idx][9] = rs.getString("tanggal");

                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DeleteLog(String idtrx) {
       try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "DELETE FROM trx_suratjalan WHERE nama_kurir=?";
            try ( java.sql.PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, idtrx);
                p.executeUpdate();
                System.out.println("suskses hapus data");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassTransaksiPengiriman.class.getName()).log(Level.SEVERE, null, ex);

        }

    }
}
