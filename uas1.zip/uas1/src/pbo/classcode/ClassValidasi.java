package pbo.classcode;




import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author pasnuria
 */
public class ClassValidasi {

    
     private String username;
    private String password;
    
    private Connection conn;
    private Statement st;
    private String level;
    
    
    public ClassValidasi(){
        
    }
    public boolean Login(String username, String password){
        boolean valid=false;
            String sql = "SELECT * FROM user WHERE username = '" + username + "' "
                    + "AND password = '" + password + "'";
        try {
            
            
            Connection conn = ClassConnection.getKoneksi();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if(rs.next()) {
                System.out.println("Selamat Datang " + username);
                valid = true;
            }else {
                System.out.println("Username atau Password salah ! ");
            }
            
            } catch (SQLException ex) {
            Logger.getLogger(ClassValidasi.class.getName()).log(Level.SEVERE, null, ex);
        }
            return valid;
    }
    
    public String Login2(String username, String password){
       
            String level = null;
            String sql = "SELECT * FROM user WHERE username = '" + username + "' "
                    + "AND password = '" + password + "'";
            try {
                conn = (Connection) ClassConnection.getKoneksi();
                st = (Statement) conn.createStatement();
                ResultSet rs = st.executeQuery(sql);
                if (rs.next()) {
                    
                    JOptionPane.showMessageDialog(null, "Selamat Datang " + username);
                    level = rs.getString("level");
                } else {
                  
                    JOptionPane.showMessageDialog(null,"Username atau password salah");
                }
            } catch (SQLException ex){
                Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }    
            return level;
    }   

}









