/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo.classcode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * 
 *
 * @author ACER
 */
public class ClassUser {

    private String nama;
    private String username;
    private String password;
    private String level;
    private int ndata = 0;
    private Object[][] data;

    private Connection conn;
    private Statement st;

   

    public int getNumberDataUser() {
        return ndata;
    }

    public Object[][] getAllDataUser() {
        return data;
    }

    

    public void TampilUser() {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "SELECT * from user";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Object[] o = new Object[4];
                o[0] = rs.getString("nama");
                o[1] = rs.getString("username");
                o[2] = rs.getString("password");
                o[3] = rs.getString("level");
                System.out.println(o[0] + "\t" + o[1] + "\t" + o[2] + "\t" + o[3]);
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void InsertUser(String nama,String username, String password, String level) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "INSERT INTO user VALUES (?, ?, ?,?)";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, nama);
                p.setString(2, username);
                p.setString(3, password);
                p.setString(4, level);
                p.execute();
                System.out.println("Sukses menambah data...");
                JOptionPane.showMessageDialog(null, "Sukses menambah data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdateUser(String nama, String username, String password, String level) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "UPDATE user SET nama=?, password=?, level=? WHERE username=?";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, nama);
                p.setString(2, password);
                p.setString(3, level);
                p.setString(4, username);
                p.executeUpdate();
                p.close();
                System.out.println("Sukses update data...");
            }
        } catch (SQLException ex) {
        Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DeleteUser(String username) {
        try {
            conn = ClassConnection.getKoneksi();
            st = conn.createStatement();
            String sql = "DELETE FROM user WHERE username=?";
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, username);
                p.executeUpdate();
                System.out.println("Sukses menghapus data...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getDataUser() {

        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from user";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from user";
            rs = st.executeQuery(sql);
            data = new Object[ndata][4];
            int idx = 0;
            while (rs.next()) {         //tangkap hasil query
                data[idx][0] = rs.getString("nama");
                data[idx][1] = rs.getString("username");
                data[idx][2] = rs.getString("password");
                data[idx][3] = rs.getString("level");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getDataUser(String key) {

        try {
            conn = (Connection) ClassConnection.getKoneksi();
            st = (Statement) conn.createStatement();
            String sql = "Select count(*) from user where username like '%" + key + "%'";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from user where username like '%" + key + "%'";
            rs = st.executeQuery(sql);
            data = new Object[ndata][4];
            int idx = 0;
            while (rs.next()) {
                data[idx][0] = rs.getString("nama");
                data[idx][1] = rs.getString("username");
                data[idx][2] = rs.getString("password");
                data[idx][3] = rs.getString("level");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
