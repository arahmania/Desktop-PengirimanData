/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo.classcode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class ClassLogActivity {

    private String tanggal, user, aktivitas;
    private Connection conn;
    private Statement st;
    private int ndata = 0;
    private Object[][] data;

    public ClassLogActivity() {

    }

    public void getDataLog() {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "Select count(*) from tb_log";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from tb_log";
            rs = st.executeQuery(sql);
            data = new Object[ndata][3];
            int idx = 0;
            while (rs.next()) {
                data[idx][0] = rs.getString("tanggal");
                data[idx][1] = rs.getString("nama_user");
                data[idx][2] = rs.getString("aktivitas");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassLogActivity.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void getDataLog(String key) {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "Select count(*) from tb_log where nama_user like '%" + key + "%'";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ndata = rs.getInt("COUNT(*)");
            }
            sql = "Select * from tb_log where nama_user like '%" + key + "%'";
            rs = st.executeQuery(sql);
            data = new Object[ndata][3];
            int idx = 0;
            while (rs.next()) {
                data[idx][0] = rs.getString("tanggal");
                data[idx][1] = rs.getString("nama_user");
                data[idx][2] = rs.getString("aktivitas");
                idx++;
            }
            rs.close();
            st.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClassLogActivity.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void InsertLog(String tanggal, String nama_user, String aktivitas) {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();    //hubungkan kelas
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "INSERT INTO tb_log VALUE (?,?,?)";    //query
            try (PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, tanggal);
                p.setString(2, nama_user);
                p.setString(3, aktivitas);
                p.execute();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassLogActivity.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void DeleteLog(String tanggal, String nama_user, String aktivitas) {
        try {
            conn = (com.mysql.jdbc.Connection) ClassConnection.getKoneksi();
            st = (com.mysql.jdbc.Statement) conn.createStatement();
            String sql = "DELETE FROM tb_log WHERE tanggal=? AND nama_user=? AND aktivitas=?";
            try (java.sql.PreparedStatement p = conn.prepareStatement(sql)) {
                p.setString(1, tanggal);
                p.setString(2, nama_user);
                p.setString(3, aktivitas);
                p.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassLogActivity.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public int getNumberDataLog() {
        return ndata;
    }

    public Object[][] getAllDataLog() {
        return data;
    }
}
