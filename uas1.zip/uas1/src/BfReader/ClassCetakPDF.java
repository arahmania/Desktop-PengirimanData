/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bfreader;

import com.itextpdf.text.Document;
 import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USER
 */
public class ClassCetakPDF {
    String nama;
    String judul;
    String isi;
    
    public ClassCetakPDF(){

    }
    
            public void CetakTeks(String nmDokumen, String isiDokumen){
            try{
                nama = nmDokumen + ".pdf";
                isi = isiDokumen;
                
                Document document = new Document();
                PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nama));
                document.open();
                Paragraph p = new Paragraph(isi);
                document.add(p);
                document.close();
                
                System.out.println("Cetak dokumen berhasil");
            } catch (FileNotFoundException ex){
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE,null, ex);
        } catch (DocumentException ex){
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE,null, ex);
        }
        }
            public void CetakTeks(String nmDokumen,String jdlDokumen, String isiDokumen){
            try{
                nama = nmDokumen + ".pdf";
                judul = jdlDokumen;
                isi = isiDokumen;
                
                Document document = new Document();
                PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nama));
                
                document.open();
                
                Paragraph p = new Paragraph(judul);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                p.setSpacingAfter(10);
                document.add(p);
                
                p = new Paragraph(isi);
                document.add(p);
                
                document.close();
                
                System.out.println("Cetak dokumen berhasil");
            } catch (FileNotFoundException ex){
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE,null, ex);
        } catch (DocumentException ex){
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE,null, ex);
        }
        }
            public void CetakGambar(String nmDokumen, String pathGambar){
        try {
            nama = nmDokumen + ".pdf";
            
            Document document = new Document();
            PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nama));
            document.open();
            Image img;
            img = Image.getInstance(pathGambar);
            img.setAlignment(Image.MIDDLE);
            img.scaleToFit(document.getPageSize().getWidth(), document.getPageSize().getHeight());
            document.add(img);
            document.close();
            
        } catch (FileNotFoundException ex) {
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException | IOException ex) {
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }  
     
    public void CetakTextGambar(String nmDokumen, String jdiDokumen, String isiDokumen, String pathGambar){
        try {
            nama = nmDokumen + ".pdf";
            judul = jdiDokumen;
            isi = isiDokumen;
            
            Document document = new Document();
            PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nama));
            document.open();
            
            Paragraph p = new Paragraph(judul);
            p.setAlignment(Paragraph.ALIGN_CENTER);
            p.setSpacingAfter(10);
            document.add(p);
            
            p = new Paragraph(isi);
            document.add(p);
            
            Image img;
            img = Image.getInstance(pathGambar);
            img.setAlignment(Image.MIDDLE);
            img.scaleToFit(document.getPageSize().getWidth(), document.getPageSize().getHeight());
            document.add(img);
            document.close();
            
        } catch (FileNotFoundException ex) {
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException | IOException ex) {
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   public void CetakTabel(String nmDokumen, String[][] isi, int bar, int kol){
        try {
            nama = nmDokumen + ".pdf";
            
            Document document = new Document();
            PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nama));
            PdfPTable pt = new PdfPTable(kol);
            document.open();
            for(int i = 0; i < bar; i++){
                for(int j = 0; j < kol; j++){
                    pt.addCell(isi[i][j]);
                }
            }
            
            document.add(pt);            
            document.close();
        } catch (FileNotFoundException | DocumentException ex) {
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  
    public void CetakTabel(String nmDokumen, String[] judulTabel, String[][] isi, int bar, int kol){
        try {
            nama = nmDokumen + ".pdf";
            
            Document document = new Document();
            PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nama));
            PdfPTable pt = new PdfPTable(kol);
            document.open();
            for(int i = 0; i < kol; i++){
                    pt.addCell(judulTabel[i]);                
            }
            for(int i = 0; i < bar; i++){
                for (int j =0; j < kol; j++){
                    pt.addCell(isi[i][j]);  
                }
            }
            
            document.add(pt);            
            document.close();
        } catch (FileNotFoundException | DocumentException ex) {
             Logger.getLogger(ClassCetakPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
