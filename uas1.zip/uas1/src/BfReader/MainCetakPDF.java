/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bfreader;

/**
 *
 * @author USER
 */
public class MainCetakPDF {
    public static void main(String[] args) {
        ClassCetakPDF cetak = new ClassCetakPDF();
        //cetak.CetakTeks("Output PDF 1", "Ini isi file dari PDF");
        //cetak.CetakTeks("Output PDF 2", "Judul Dari Dokumen", "Ini isi file dari PDF 2");
        //cetak.CetakGambar("Output PDF 3", "gambar.jpg");
        //cetak.CetakTextGambar("Output PDF 4", "KAMPUSKU","Ini adalah gambar kampusku","gambar.jpg");
        String[][] isi = new String[2][2];
        isi[0][0]="A";
        isi[0][1]="B";
        isi[1][0]="C";
        isi[1][1]="D";
        cetak.CetakTabel("Output PDF 5", isi, 2, 2);
        String[] judul = new String[2];
        judul[0]="Baris";
        judul[1]="Kolom";
        cetak.CetakTabel("Output PDF 6", judul, isi, 2, 2);
    }
}
