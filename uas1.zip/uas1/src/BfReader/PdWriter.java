/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bfreader;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author USER
 */
public class PdWriter {
    public static void main(String[] args) {
        try{
            String nmDokumen = "file PDF.pdf";
            Document document = new Document() ;
            PdfWriter pw = PdfWriter.getInstance(document, new FileOutputStream(nmDokumen));
            document.open();
            String isi = "Ini membuat file pdf dari Java";
            Paragraph para = new Paragraph(isi);
            document.add(para);
            document.close();
        } catch (FileNotFoundException | DocumentException ex){
             Logger.getLogger(PdWriter.class.getName()).log(Level.SEVERE,null, ex);
        }
    }
}
