/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bfreader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author USER
 */
public class BfWriter {
    public static void main(String[] args) {
        try{
            File file = new File("file java yang ditulis.txt");
            String text = "Ini membuat file txt dari Java"+
                    "\nIni adalah teks yang dicetak";
            if (file.createNewFile()){
                System.out.println("File berhasil dibuat");
            } else {
                System.out.println("file sudah pernah dibuat");
            }
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bf = new BufferedWriter(fw);
            bf.write(text);
            bf.close();
        } catch (IOException ex){
            System.err.println("Terjadi kesalahan menulis file");
            ex.printStackTrace();
        }
    }
}
