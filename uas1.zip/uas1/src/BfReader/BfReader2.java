/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BfReader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author asus
 */
public class BfReader2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
             try{
         String line;
         BufferedReader reader = new BufferedReader(new FileReader("File untuk dibaca.txt"));
         while ((line = reader.readLine()) != null) {
             System.out.println(line);
         }
         if (reader != null){
             reader.close();
         }
     } catch (IOException e){
         e.printStackTrace();
     }
        
    }
    
}
