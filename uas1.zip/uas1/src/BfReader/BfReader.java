/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BfReader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author asus
 */
public class BfReader {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String name;
            System.out.print("Masukkan nama Anda : ");
            name = br.readLine();
            System.out.println("Hello " + name + "!");
        } catch (IOException ex){
             Logger.getLogger(BfReader.class.getName()).log(Level.SEVERE,null, ex);
        }
    } // TODO code application logic here
    }
    

